import React from "react";
import { Divider, Card, Tabs } from "antd";
import StudentPageLayout from "../Layout/StudentPageLayout";

const { TabPane } = Tabs;

const data = [
  {
    title: "Assignment 1",
    desc: "Proident exercitation nisi labore sint laboris proident deserunt laborum culpa enim veniam est."
  },
  {
    title: "Assignment 2",
    desc: "Proident exercitation nisi labore sint laboris proident deserunt laborum culpa enim veniam est."
  },
  {
    title: "Assignment 3",
    desc: "Proident exercitation nisi labore sint laboris proident deserunt laborum culpa enim veniam est."
  },
  {
    title: "Assignment 4",
    desc: "Proident exercitation nisi labore sint laboris proident deserunt laborum culpa enim veniam est."
  },
  {
    title: "Assignment 5",
    desc: "Proident exercitation nisi labore sint laboris proident deserunt laborum culpa enim veniam est."
  }
];

const tabData = ["TAMIL", "ENGLISH", "MATHS", "SCIENCE", "SOCIAL"];

const AssignmentsTab = ({ title, data, tabData }) => (
  <div style={{ margin: "10px", maxWidth: 500, width: "100%" }}>
    <h2>{title}</h2>
    <Tabs defaultActiveKey="0">
      {tabData.map((code, index) => (
        <TabPane tab={code} key={index}>
          {data.map((item, idx) => (
            <Card key={idx} title={item.title} style={{ marginBottom: 16 }}>
              {item.desc}
            </Card>
          ))}
        </TabPane>
      ))}
    </Tabs>
  </div>
);

const AssignmentHome = () => (
  <StudentPageLayout menuSelect="3">
    <div
      style={{
        display: "flex",
        flexWrap: "wrap",
        justifyContent: "center",
        gap: "20px"
      }}
    >
      <AssignmentsTab title="On-Going" data={data} tabData={tabData} />
      <Divider style={{ width: "100%" }} />
      <AssignmentsTab title="Completed" data={data} tabData={tabData} />
    </div>
  </StudentPageLayout>
);

export default AssignmentHome;
