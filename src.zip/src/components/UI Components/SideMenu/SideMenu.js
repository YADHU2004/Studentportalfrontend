import React, { Component } from "react";
import { Layout, Menu } from "antd";
import Classes from "../../../index.module.css";
import {
  MenuUnfoldOutlined,
  MenuFoldOutlined,
  UserOutlined,
  CalendarOutlined,
  BookOutlined,
  SettingOutlined,
  LogoutOutlined
} from "@ant-design/icons";

class SideMenu extends Component {
  state = {
    collapsed: true
  };

  toggle = () => {
    this.setState({
      collapsed: !this.state.collapsed
    });
  };

  render() {
    const { Sider } = Layout;

    return (
      <Sider
        trigger={null}
        theme="light"
        collapsible
        collapsed={this.state.collapsed}
      >
        {/* Use MenuUnfoldOutlined and MenuFoldOutlined here */}
        {this.state.collapsed ? (
          <MenuUnfoldOutlined
            className="trigger"
            onClick={this.toggle}
            style={{
              fontSize: 25,
              marginTop: 25,
              paddingRight: this.state.collapsed ? 0 : 10,
              textAlign: this.state.collapsed ? "center" : "right",
              width: "100%"
            }}
          />
        ) : (
          <MenuFoldOutlined
            className="trigger"
            onClick={this.toggle}
            style={{
              fontSize: 25,
              marginTop: 25,
              paddingRight: this.state.collapsed ? 0 : 10,
              textAlign: this.state.collapsed ? "center" : "right",
              width: "100%"
            }}
          />
        )}
        <Menu
          theme="light"
          mode="inline"
          className={Classes.sideNav}
          defaultSelectedKeys={[this.props.menuSelect]}
        >
          <Menu.Item key="1">
            <a href="/me">
              <UserOutlined />
              <span>Dashboard</span>
            </a>
          </Menu.Item>
          <Menu.Item key="2">
            <a href="/attendance">
              <CalendarOutlined />
              <span>Attendance</span>
            </a>
          </Menu.Item>
          <Menu.Item key="3">
            <a href="/assignments">
              <BookOutlined />
              <span>Assignments</span>
            </a>
          </Menu.Item>
          <Menu.Item key="4">
            <a href="/settings">
              <SettingOutlined />
              <span>Settings</span>
            </a>
          </Menu.Item>
          <Menu.Item key="5">
            <a href="/login">
              <LogoutOutlined />
              <span>Logout</span>
            </a>
          </Menu.Item>
        </Menu>
      </Sider>
    );
  }
}

export default SideMenu;
