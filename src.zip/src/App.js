import React from "react";
import { Layout } from "antd";
import { Route, Routes } from "react-router-dom";
import { CopyrightOutlined } from "@ant-design/icons"; // Updated Icon import

import "./App.css";
import StudentHome from "./components/Student/Home/StudentHome";
import WrappedNormalLoginForm from "./components/Login/Login";
import AttendancePage from "./components/Student/AttendancePage/AttendancePage";
import Header from "./components/UI Components/Header/Header";


import Classes from "./index.module.css";
import Error404 from "./components/Error404/Error404";
import AssignmentHome from "./components/Student/Assignment/AssignmentHome";
import RegisterForm from "./components/Register/Register";
import LoginForm from "./components/Login/Login";


function App() {
  return (
    <>
      <Routes>
        <Route path="/login" element={<LoginForm/>} />
      
        <Route
          path="/register"
          element={
            <>
              <Header />
              <Layout.Content>
                <RegisterForm />
              </Layout.Content>
            </>
          }
        />
         <Route path="/StudentHome" element={<StudentHome />} />
        <Route path="/attendance" element={<AttendancePage />} />
        <Route path="/assignments" element={<AssignmentHome />} />
        <Route path="*" element={<Error404 />} />
      </Routes>
      <Layout.Footer className={Classes.footer}>
        <CopyrightOutlined style={{ fontSize: "16px" }} />
        &nbsp;Student Portal
      </Layout.Footer>
    </>
  );
}

export default App;

